#pragma once
void NewFunction();
