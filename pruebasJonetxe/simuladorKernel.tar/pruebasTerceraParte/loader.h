
#ifndef LOADER_H
#define LOADER_H

#include "globales.h"

int Loader();
PCB* cargarProceso(int pid);

#endif